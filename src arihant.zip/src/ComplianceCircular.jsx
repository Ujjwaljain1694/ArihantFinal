import React, { useState, useEffect } from "react";
import Header from "./Header.jsx";

export default function ComplianceCircular() {
  const [data, setData] = useState([]);
  const [type, setType] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [sortConfig, setSortConfig] = useState({
    key: "",
    direction: "asc",
  });

  // FETCH DATA (Backend Ready)
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // 👉 replace with your API
      const res = await fetch("http://localhost:5000/api/circulars");
      const result = await res.json();
      setData(result);
    } catch (err) {
      console.log(err);
    }
  };

  // 🔍 FILTER APPLY
  const handleApply = () => {
    let filtered = [...data];

    if (type) {
      filtered = filtered.filter((item) => item.type === type);
    }

    if (fromDate) {
      filtered = filtered.filter(
        (item) => new Date(item.date) >= new Date(fromDate)
      );
    }

    if (toDate) {
      filtered = filtered.filter(
        (item) => new Date(item.date) <= new Date(toDate)
      );
    }

    setData(filtered);
  };

  // 🚀 SORT FUNCTION
  const handleSort = (key) => {
    let direction = "asc";

    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }

    setSortConfig({ key, direction });

    const sortedData = [...data].sort((a, b) => {
      if (a[key] < b[key]) return direction === "asc" ? -1 : 1;
      if (a[key] > b[key]) return direction === "asc" ? 1 : -1;
      return 0;
    });

    setData(sortedData);
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />

      <div className="p-6 pt-0">

        {/* FILTER SECTION */}
        <div className="bg-gray-200 p-5 rounded-lg flex flex-wrap gap-6 items-end pt-3 pb-4 ">

          {/* FROM DATE */}
          <div className="mt-0">
            <p className="text-sm mb-1">From Date</p>
            <input
              type="date"
              className="px-4 py-2 rounded border w-52"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
            />
          </div>

          {/* TO DATE */}
          <div className="mt-0">
            <p className="text-sm mb-1">To Date</p>
            <input
              type="date"
              className="px-4 py-2 rounded border w-52"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
            />
          </div>

          {/* DROPDOWN */}
          <div className="mt-0">
            <p className="text-sm mb-1">Search By Circular Type</p>
            <div className="relative w-56">
              <select
                className="px-4 py-2 rounded bg-gray-700 text-white w-56 appearance-none pr-10"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="">Select Type</option>
                <option value="NSE">NSE</option>
                <option value="BSE">BSE</option>
                <option value="Others">Others</option>
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>

          {/* APPLY BUTTON (ENHANCED) */}
          <button
            onClick={handleApply}
            className="bg-gradient-to-r from-green-500 to-green-700 
            hover:from-green-600 hover:to-green-800 
            text-white px-8 py-3 rounded-full font-semibold 
            shadow-md hover:shadow-xl 
            transition-all duration-300 active:scale-95"
          >
            APPLY →
          </button>
        </div>

        {/* � TABLE */}
        <div className="mt-6 border rounded-md overflow-hidden bg-white">

          {/* HEADER */}
          <div className="grid grid-cols-3 bg-green-600 text-white text-sm font-semibold">

            {/* TYPE */}
            <div
              onClick={() => handleSort("type")}
              className="p-3 border-r flex items-center justify-between cursor-pointer"
            >
              Compliance Type
              <i
                className={`fa ${
                  sortConfig.key === "type"
                    ? sortConfig.direction === "asc"
                      ? "fa-sort-up"
                      : "fa-sort-down"
                    : "fa-sort"
                }`}
              />
            </div>

            {/* FILE */}
            <div
              onClick={() => handleSort("file")}
              className="p-3 border-r flex items-center justify-between cursor-pointer"
            >
              File
              <i
                className={`fa ${
                  sortConfig.key === "file"
                    ? sortConfig.direction === "asc"
                      ? "fa-sort-up"
                      : "fa-sort-down"
                    : "fa-sort"
                }`}
              />
            </div>

            {/* DATE */}
            <div
              onClick={() => handleSort("date")}
              className="p-3 flex items-center justify-between cursor-pointer"
            >
              Date
              <i
                className={`fa ${
                  sortConfig.key === "date"
                    ? sortConfig.direction === "asc"
                      ? "fa-sort-up"
                      : "fa-sort-down"
                    : "fa-sort"
                }`}
              />
            </div>

          </div>

          {/* BODY WITH SCROLL */}
          <div className="max-h-[350px] overflow-y-auto">

            {data.map((item, index) => (
              <div
                key={index}
                className="grid grid-cols-3 text-sm border-t"
              >
                <div className="p-3 border-r">{item.type}</div>

                <div className="p-3 border-r text-blue-600 cursor-pointer hover:underline">
                  {item.file}
                </div>

                <div className="p-3">{item.date}</div>
              </div>
            ))}

          </div>

          {/* FOOTER */}
          <div className="p-3 text-xs text-gray-500">
            {data.length} total
          </div>
        </div>
      </div>
    </div>
  );
}